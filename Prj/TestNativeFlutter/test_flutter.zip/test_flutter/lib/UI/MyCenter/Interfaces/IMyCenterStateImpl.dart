import 'package:test_flutter/commonbase/Base/UIBase/IBaseStateImpl.dart';

abstract class IMyCenterPageState extends IBaseStateImpl
{

}