import 'package:test_flutter/Bean/user_info.dart';
import 'package:test_flutter/commonbase/Base/PresenterBase/IBasePresenter.dart';

abstract class IMyCenterPresenter extends IBasePresenter
{
    void login();
}