class APIUrl
{
  // static const String BASE_URL = 'http://127.0.0.1:6001/';
  static const String BASE_URL = 'https://app-ptest.vavafood.com/';

  static const String DO_LOGIN = BASE_URL+'mi/base/user/login/in';
}