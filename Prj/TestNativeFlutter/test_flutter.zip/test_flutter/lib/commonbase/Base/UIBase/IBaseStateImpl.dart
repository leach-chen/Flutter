abstract class IBaseStateImpl
{
  //void init();
  initWidget();
}