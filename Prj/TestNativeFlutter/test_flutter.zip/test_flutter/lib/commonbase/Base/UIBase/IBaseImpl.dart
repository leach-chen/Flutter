import 'package:flutter/cupertino.dart';

abstract class IBaseImpl
{
  //void init();
  State initPage();
}