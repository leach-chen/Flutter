abstract class IBasePresenter
{
}