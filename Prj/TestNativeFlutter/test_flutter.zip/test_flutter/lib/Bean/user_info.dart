class UserInfo {
  String stateCode;
  String stateMsg;

  UserInfo(stateCode,stateMsg)
  {
    this.stateCode = stateCode;
    this.stateMsg = stateMsg;
  }

}
